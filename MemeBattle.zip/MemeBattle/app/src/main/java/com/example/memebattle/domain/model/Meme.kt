package com.example.memebattle.domain.model

data class Meme(
    val id: Long,
    val imageMeme: String
)
