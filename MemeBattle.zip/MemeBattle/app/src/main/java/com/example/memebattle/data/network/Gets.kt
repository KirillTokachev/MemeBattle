package com.example.memebattle.data.network

object Gets {
    const val API_KEY = "XDTnqgr9tyyLRiN8kGfhFjKxMxGSieZm4Tviu0yq"
    const val APP_ID = "5lFX9vtjpPCP4Obtkcs7z3gpFn2UlAkQoAJC0Pzu"
    const val QUESTION = "classes/Questions"
    const val MEME = "classes/Meme"
}