package com.example.memebattle.domain.model

data class Question(
    val id: Long,
    val question: String
)
